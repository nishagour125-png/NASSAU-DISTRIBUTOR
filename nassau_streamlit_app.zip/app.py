import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(
    page_title="Nassau Candy Distributor | Sales Dashboard",
    page_icon="🍬",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_FILE = Path(__file__).parent / "Nassau Candy Distributor.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_FILE)
    df["Order Date"] = pd.to_datetime(df["Order Date"], dayfirst=True, errors="coerce")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], dayfirst=True, errors="coerce")
    for col in ["Sales", "Units", "Gross Profit", "Cost"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    df["Profit Margin %"] = df["Gross Profit"].div(df["Sales"].replace(0, pd.NA)).mul(100).fillna(0)
    df["Month"] = df["Order Date"].dt.to_period("M").dt.to_timestamp()
    df["Order Month"] = df["Order Date"].dt.strftime("%b %Y")
    return df

df = load_data()

# ---------- Header ----------
st.title("🍬 Nassau Candy Distributor")
st.caption("Interactive Sales, Profit & Distribution Performance Dashboard")

# ---------- Sidebar ----------
st.sidebar.header("🔎 Dashboard Filters")

min_date = df["Order Date"].min().date()
max_date = df["Order Date"].max().date()

date_range = st.sidebar.date_input(
    "Order Date",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
)

if isinstance(date_range, tuple) and len(date_range) == 2:
    start_date, end_date = date_range
else:
    start_date, end_date = min_date, max_date

regions = st.sidebar.multiselect(
    "Region",
    options=sorted(df["Region"].dropna().unique()),
    default=sorted(df["Region"].dropna().unique()),
)
divisions = st.sidebar.multiselect(
    "Division",
    options=sorted(df["Division"].dropna().unique()),
    default=sorted(df["Division"].dropna().unique()),
)
ship_modes = st.sidebar.multiselect(
    "Ship Mode",
    options=sorted(df["Ship Mode"].dropna().unique()),
    default=sorted(df["Ship Mode"].dropna().unique()),
)

filtered = df[
    (df["Order Date"].dt.date >= start_date)
    & (df["Order Date"].dt.date <= end_date)
    & (df["Region"].isin(regions))
    & (df["Division"].isin(divisions))
    & (df["Ship Mode"].isin(ship_modes))
].copy()

# ---------- KPIs ----------
sales = filtered["Sales"].sum()
units = filtered["Units"].sum()
profit = filtered["Gross Profit"].sum()
cost = filtered["Cost"].sum()
margin = (profit / sales * 100) if sales else 0
orders = filtered["Order ID"].nunique()
customers = filtered["Customer ID"].nunique()

k1, k2, k3, k4, k5, k6 = st.columns(6)
k1.metric("Total Sales", f"${sales:,.0f}")
k2.metric("Units Sold", f"{units:,.0f}")
k3.metric("Gross Profit", f"${profit:,.0f}")
k4.metric("Total Cost", f"${cost:,.0f}")
k5.metric("Profit Margin", f"{margin:.1f}%")
k6.metric("Orders", f"{orders:,}")

st.divider()

# ---------- Charts ----------
left, right = st.columns(2)

with left:
    st.subheader("📈 Monthly Sales Trend")
    monthly = (
        filtered.groupby("Month", as_index=False)["Sales"]
        .sum()
        .sort_values("Month")
    )
    fig = px.line(
        monthly,
        x="Month",
        y="Sales",
        markers=True,
        labels={"Month": "Month", "Sales": "Sales ($)"},
    )
    fig.update_layout(height=380, margin=dict(l=10, r=10, t=20, b=10))
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("🌎 Sales by Region")
    region_sales = (
        filtered.groupby("Region", as_index=False)["Sales"]
        .sum()
        .sort_values("Sales", ascending=False)
    )
    fig = px.bar(
        region_sales,
        x="Region",
        y="Sales",
        text_auto=".2s",
        labels={"Sales": "Sales ($)"},
    )
    fig.update_layout(height=380, margin=dict(l=10, r=10, t=20, b=10))
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)

with left:
    st.subheader("🍫 Sales by Division")
    division_sales = (
        filtered.groupby("Division", as_index=False)["Sales"]
        .sum()
        .sort_values("Sales", ascending=False)
    )
    fig = px.pie(
        division_sales,
        names="Division",
        values="Sales",
        hole=0.45,
    )
    fig.update_layout(height=380, margin=dict(l=10, r=10, t=20, b=10))
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("💰 Sales vs Gross Profit by Region")
    region_perf = (
        filtered.groupby("Region", as_index=False)[["Sales", "Gross Profit"]]
        .sum()
        .melt(id_vars="Region", var_name="Metric", value_name="Amount")
    )
    fig = px.bar(
        region_perf,
        x="Region",
        y="Amount",
        color="Metric",
        barmode="group",
        labels={"Amount": "Amount ($)"},
    )
    fig.update_layout(height=380, margin=dict(l=10, r=10, t=20, b=10))
    st.plotly_chart(fig, use_container_width=True)

# ---------- Top products ----------
st.subheader("🏆 Top 10 Products by Sales")
top_products = (
    filtered.groupby("Product Name", as_index=False)
    .agg(Sales=("Sales", "sum"), Gross_Profit=("Gross Profit", "sum"), Units=("Units", "sum"))
    .sort_values("Sales", ascending=False)
    .head(10)
)

fig = px.bar(
    top_products.sort_values("Sales"),
    x="Sales",
    y="Product Name",
    orientation="h",
    text_auto=".2s",
    labels={"Sales": "Sales ($)", "Product Name": "Product"},
)
fig.update_layout(height=500, margin=dict(l=10, r=10, t=20, b=10))
st.plotly_chart(fig, use_container_width=True)

# ---------- Summary tables ----------
c1, c2 = st.columns(2)

with c1:
    st.subheader("🚚 Sales by Ship Mode")
    ship_summary = (
        filtered.groupby("Ship Mode", as_index=False)
        .agg(Sales=("Sales", "sum"), Orders=("Order ID", "nunique"))
        .sort_values("Sales", ascending=False)
    )
    st.dataframe(
        ship_summary.style.format({"Sales": "${:,.2f}", "Orders": "{:,}"}),
        use_container_width=True,
        hide_index=True,
    )

with c2:
    st.subheader("📊 Region Performance")
    region_summary = (
        filtered.groupby("Region", as_index=False)
        .agg(
            Sales=("Sales", "sum"),
            Gross_Profit=("Gross Profit", "sum"),
            Units=("Units", "sum"),
        )
    )
    region_summary["Margin %"] = (
        region_summary["Gross_Profit"] / region_summary["Sales"].replace(0, pd.NA) * 100
    ).fillna(0)
    region_summary = region_summary.sort_values("Sales", ascending=False)
    st.dataframe(
        region_summary.style.format(
            {"Sales": "${:,.2f}", "Gross_Profit": "${:,.2f}", "Units": "{:,.0f}", "Margin %": "{:.1f}%"}
        ),
        use_container_width=True,
        hide_index=True,
    )

# ---------- Customer summary ----------
st.subheader("👥 Customer Performance")
customer_summary = (
    filtered.groupby("Customer ID", as_index=False)
    .agg(
        Sales=("Sales", "sum"),
        Gross_Profit=("Gross Profit", "sum"),
        Units=("Units", "sum"),
        Orders=("Order ID", "nunique"),
    )
    .sort_values("Sales", ascending=False)
    .head(10)
)
st.dataframe(
    customer_summary.style.format(
        {"Sales": "${:,.2f}", "Gross_Profit": "${:,.2f}", "Units": "{:,.0f}", "Orders": "{:,}"}
    ),
    use_container_width=True,
    hide_index=True,
)

# ---------- Download ----------
st.divider()
csv_data = filtered.to_csv(index=False).encode("utf-8")
st.download_button(
    "⬇️ Download Filtered Data",
    data=csv_data,
    file_name="nassau_filtered_data.csv",
    mime="text/csv",
)

st.caption(
    f"Showing {len(filtered):,} rows | {customers:,} unique customers | "
    f"Data period: {start_date} to {end_date}"
)
