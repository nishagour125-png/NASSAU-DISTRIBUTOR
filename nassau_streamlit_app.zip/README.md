# Nassau Candy Distributor Dashboard

Interactive Streamlit dashboard for sales, profit, product, region, customer and shipping analysis.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Files

- `app.py` - Streamlit dashboard
- `Nassau Candy Distributor.csv` - source dataset
- `requirements.txt` - Python dependencies

## Dashboard Features

- KPI cards: Sales, Units, Gross Profit, Cost, Margin and Orders
- Date, Region, Division and Ship Mode filters
- Monthly sales trend
- Region-wise sales
- Division sales mix
- Sales vs Gross Profit by region
- Top 10 products
- Ship mode summary
- Region performance table
- Top customer table
- Filtered CSV download
